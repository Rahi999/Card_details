import "./styles.css";
import Card from "./components/card"

export default function App() {
  return (
    <div className="App">
      <Card />
    </div>
  );
}
